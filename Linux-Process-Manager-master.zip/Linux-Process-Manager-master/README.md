# Linux-Process-Manager

A C program that allows the user to manage multiple processes on Linux

Instructions:

1. Open terminal
2. Use cd to get to the directory where PMan.c and Makefile are stored
3. Type "make" to compile the C program
4. Type "./PMan" to run the program
